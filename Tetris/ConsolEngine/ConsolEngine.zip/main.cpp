// Copyright 2009-2014 Blam Games, Inc. All Rights Reserved.

#include "TestApp.h"

void main()
{
	TestApp app;
	app.Run();
}

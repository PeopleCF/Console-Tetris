#pragma once
class IListener
{

};